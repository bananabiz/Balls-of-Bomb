﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Collision : MonoBehaviour
{
    public Rigidbody2D bomb;
    public ScoreManager scoreManager;
    private void Start()
    {
        bomb = GetComponent<Rigidbody2D>();
        scoreManager = GameObject.Find("Score").GetComponent<ScoreManager>();
    }

    private void OnCollisionEnter2D(Collision2D bomb)
    {
        if (bomb.gameObject.tag == "Bomb")
        {
            Destroy(bomb.gameObject, 0.2f);

            scoreManager.score++;
            
        }
        
    }
   
}